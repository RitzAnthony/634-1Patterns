package observerPattern.ex1;

public interface MyObserver {

    void update (PatientMonitoring.Problem problem);
}
