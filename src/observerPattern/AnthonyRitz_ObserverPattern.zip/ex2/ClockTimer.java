package observerPattern.ex2;

public interface ClockTimer {
    public int getHour();
    public int getMinute();
    public int getSecond();
    public void tick();
}

