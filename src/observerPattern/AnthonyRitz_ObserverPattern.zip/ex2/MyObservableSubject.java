package observerPattern.ex2;

public interface MyObservableSubject {

    void addObserver (MyObserver observer);
}
