package observerPattern.ex2;

public interface MyObserver {

    void update ();
}
